"""Settings of the reel kit: sizes, colours, the name shown in the header and the line shown in the footer. Change them here."""
import os
ROOT = os.path.dirname(os.path.abspath(__file__))
W, H = 1080, 1920
BG, FG, DIM, UP, DOWN, ACC = (11, 14, 20), (240, 242, 245), (140, 148, 160), (64, 200, 130), (235, 90, 90), (90, 160, 255)
NAME = "Your channel"                  # header, first line
SUB = "made with the reel kit"         # header, second line
FOOT = ""                              # small line under the card, e.g. a disclaimer
LOGO = os.path.join(ROOT, "logo.png")  # optional square image for the header; a plain dot is drawn if the file is missing
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"      # fallback fonts if the Inter files in fonts/ are missing
FONT_R = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def wrap(d, text, font, width):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for w in para.split():
            t = (cur + " " + w).strip()
            if d.textlength(t, font=font) <= width: cur = t
            else: lines.append(cur); cur = w
        lines.append(cur)
    return lines


def chart(*a):
    raise NotImplementedError("the chart part belongs to the original project and is not in the kit")
