#!/usr/bin/env python3
"""Renderer of the reel kit: draws every frame (text cards, running captions, progress bar) and pipes it to ffmpeg."""
import os, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import kitbase as iv

W, H, FPS = iv.W, iv.H, 30
FD = os.path.join(iv.ROOT, "fonts")
FONTS = {True: os.path.join(FD, "Inter-ExtraBold.ttf"), False: os.path.join(FD, "Inter-Regular.ttf"), "semi": os.path.join(FD, "Inter-SemiBold.ttf")}
ANIM, XFADE, RISE = 0.40, 0.22, 46          # seconds a part needs to arrive, crossfade between slides, pixels it rises
TOP = 200                                   # y of the progress bar: Instagram covers the area above with its own header
CAPY = 1250                                  # y of the running captions (spoken words)
CY, FOOT, MX = 850, 1400, 60                # centre of the text block, y of the footer (below about y=1440 Instagram shows the caption), side margin of the card
# these are the portrait values; setup() switches to 1920x1080 for long YouTube videos
_fc = {}


def setup(wide):
    """Portrait 1080x1920 for reels, or landscape 1920x1080 ("format": "wide" in the script) for long YouTube videos."""
    global W, H, TOP, CY, FOOT, MX
    W, H, TOP, CY, FOOT, MX = (1920, 1080, 36, 575, 1010, 150) if wide else (iv.W, iv.H, 200, 850, 1400, 60)


def font(size, kind=True):
    if (size, kind) not in _fc: _fc[(size, kind)] = ImageFont.truetype(FONTS[kind] if os.path.exists(FONTS[kind]) else (iv.FONT if kind else iv.FONT_R), size)
    return _fc[(size, kind)]


def background():
    y = np.linspace(0, 1, H)[:, None, None]; top = np.array([8, 11, 19.]); bot = np.array([15, 21, 38.])
    a = np.broadcast_to(top + (bot - top) * y, (H, W, 3)).copy(); yy, xx = np.mgrid[0:H, 0:W]
    for cx, cy, r, col, k in ((W * 0.85, H * 0.18, 620, (70, 130, 255), 0.20), (W * 0.10, H * 0.80, 700, (50, 200, 130), 0.10)):
        a += np.exp(-((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * r * r))[:, :, None] * np.array(col) * k
    a += np.random.default_rng(64).normal(0, 1.2, (H, W, 1))                 # light grain against banding after Instagram's re-encode
    return Image.fromarray(np.clip(a, 0, 255).astype("uint8"), "RGB")


def layout(parts):
    """-> list of (strip RGBA, y): every part drawn once on a transparent strip of full width, plus the card box."""
    d = ImageDraw.Draw(Image.new("RGB", (8, 8))); blocks = []; total = 0; gap = 44
    for p in parts:
        if p[0] == "chart": blocks.append(("chart", p[1], 620)); total += 620 + gap
        else:
            text, size, col, bold = p; f = font(size, bold); lines = iv.wrap(d, text, f, W - 2 * MX - 100); lh = int(size * 1.22)
            blocks.append(("text", lines, f, col, lh, size)); total += lh * len(lines) + gap
    total -= gap; y0 = max(TOP + (190 if W > H else 210), CY - total // 2); y = y0; out = []
    for b in blocks:
        if b[0] == "chart":
            s = Image.new("RGBA", (W, b[2]), (0, 0, 0, 0)); iv.chart(ImageDraw.Draw(s), b[1], MX + 50, 0, W - 2 * MX - 100, b[2]); out.append((s, y)); y += b[2] + gap
        else:
            _, lines, f, col, lh, size = b; hh = lh * len(lines) + 40; s = Image.new("RGBA", (W, hh), (0, 0, 0, 0)); ds = ImageDraw.Draw(s)
            for li, ln in enumerate(lines): ds.text(((W - ds.textlength(ln, font=f)) // 2, 14 + li * lh), ln, font=f, fill=col + (255,))
            if size >= 120:                                                  # big numbers get a soft glow in their own colour
                g = s.filter(ImageFilter.GaussianBlur(22)); g.putalpha(g.getchannel("A").point(lambda v: int(v * 0.45))); s = Image.alpha_composite(g, s)
            out.append((s, y - 14)); y += lh * len(lines) + gap
    box = (MX, y0 - 60, W - MX, y0 + total + 60)
    return out, box


def base(bg, logo, tag, box):
    im = bg.copy().convert("RGBA"); ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    d.rounded_rectangle(box, radius=44, fill=(255, 255, 255, 12), outline=(255, 255, 255, 34), width=2)
    im = Image.alpha_composite(im, ov); im.paste(logo, (70, TOP + 40), logo); d = ImageDraw.Draw(im)
    d.text((70 + 84, TOP + 44), iv.NAME, font=font(34, "semi"), fill=iv.FG); d.text((70 + 84, TOP + 86), iv.SUB, font=font(24, False), fill=iv.DIM)
    if tag:
        f = font(30, True); tw = d.textlength(tag, font=f); x1 = W - 70
        d.rounded_rectangle([x1 - tw - 44, TOP + 48, x1, TOP + 48 + 58], radius=29, fill=iv.ACC); d.text((x1 - tw - 22, TOP + 58), tag, font=f, fill=(8, 11, 19))
    foot = iv.FOOT; f = font(32, False); d.text(((W - d.textlength(foot, font=f)) // 2, max(FOOT, box[3] + 24)), foot, font=f, fill=iv.DIM)
    return im.convert("RGB")


def bar(im, n, i, frac):
    d = ImageDraw.Draw(im); seg = W / n
    for q in range(n):
        x0, x1 = q * seg + 8, (q + 1) * seg - 8; d.rounded_rectangle([x0, TOP, x1, TOP + 10], radius=5, fill=(44, 52, 68))
        if q < i or (q == i and frac > 0.02): d.rounded_rectangle([x0, TOP, x0 + (x1 - x0) * (1 if q < i else frac), TOP + 10], radius=5, fill=iv.FG)


def audio(wavs, durs, ticks, path):
    w = wave.open(wavs[0]); rate = w.getframerate(); w.close(); out = []
    for p, dur in zip(wavs, durs):
        w = wave.open(p); a = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype("float32")
        if w.getnchannels() == 2: a = a.reshape(-1, 2).mean(1)
        if w.getframerate() != rate: a = np.interp(np.arange(0, len(a), w.getframerate() / rate), np.arange(len(a)), a)
        w.close(); n = int(round(dur * rate)); out.append(np.pad(a, (0, max(0, n - len(a))))[:n])
    a = np.concatenate(out); t = np.arange(int(0.07 * rate)) / rate
    tick = np.sin(2 * np.pi * 1320 * t) * np.exp(-t * 70) * 32767 * 0.05     # short, quiet, far below the voice
    for s in ticks:
        k = int(s * rate)
        if k + len(tick) < len(a): a[k:k + len(tick)] += tick
    w = wave.open(path, "w"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(np.clip(a, -32767, 32767).astype("<i2").tobytes()); w.close()


def captions(say, dur):
    """Spoken words as running captions: chunks of up to three words, timed by their share of the characters (close enough without word timestamps)."""
    words = say.split(); chunks = []; cur = []
    for w in words:
        cur.append(w)
        if len(cur) == 3 or len(" ".join(cur)) >= 16 or w[-1] in ".?!:,": chunks.append(" ".join(cur)); cur = []
    if cur: chunks.append(" ".join(cur))
    total = sum(len(c) + 1 for c in chunks) or 1; span = max(0.5, dur - 0.35); t = 0.0; out = []; f = font(56, True)
    for c in chunks:
        d = span * (len(c) + 1) / total; txt = c.strip(" ,"); probe = ImageDraw.Draw(Image.new("RGBA", (10, 10))); tw = probe.textlength(txt, font=f)
        im = Image.new("RGBA", (int(tw) + 72, 96), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, im.width - 1, 95], radius=26, fill=(8, 12, 22, 215)); dr.text((36, 14), txt, font=f, fill=(255, 255, 255, 255))
        out.append((t, t + d, im)); t += d
    return out


def render(sc, wavs, durs, hours, mp4, tmp):
    setup(sc.get("format") == "wide"); n = len(sc["segments"]); bg = background(); ease = lambda x: 1 - (1 - min(1.0, max(0.0, x))) ** 3
    logo = Image.open(iv.LOGO).convert("RGBA").resize((68, 68), Image.LANCZOS) if os.path.exists(iv.LOGO) else Image.new("RGBA", (68, 68), iv.ACC + (255,))
    m = Image.new("L", (68, 68), 0); ImageDraw.Draw(m).ellipse([0, 0, 67, 67], fill=255); logo.putalpha(m)
    segs = []; ticks = []; t0 = 0.0
    for i, s in enumerate(sc["segments"]):
        parts = [("chart", hours) if p[0] == "chart" else (p[0], p[1], iv.__dict__[{"fg": "FG", "dim": "DIM", "acc": "ACC", "up": "UP", "down": "DOWN"}[p[2]]], p[3]) for p in s["parts"]]
        strips, box = layout(parts); k = len(strips)
        if i == 0: starts = [-ANIM] * k                                    # the hook slide is complete on frame 1: platforms take that frame as the thumbnail
        else: starts = [j * durs[i] * 0.6 / k for j in range(k)] if sc.get("reveal") and k > 1 else [0.10 + j * 0.14 for j in range(k)]
        ticks += [t0 + x for x in starts[1:]] if sc.get("reveal") and i > 0 else []
        segs.append((base(bg, logo, s.get("tag"), box), strips, starts, captions(s["say"], durs[i]) if sc.get("captions", True) and sc.get("format") != "wide" else [])); t0 += durs[i]
    wav = os.path.join(tmp, "all.wav"); audio(wavs, durs, ticks, wav)
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "%dx%d" % (W, H), "-r", str(FPS), "-i", "-", "-i", wav,
                           "-vf", "scale=out_color_matrix=bt709:out_range=tv", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
                           "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-profile:v", "high", "-pix_fmt", "yuv420p", "-g", "60",
                           "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2", "-movflags", "+faststart", mp4], stdin=subprocess.PIPE)
    done = 0; end = 0.0; prev = None
    for i, (b, strips, starts, caps) in enumerate(segs):
        end += durs[i]; frames = int(round(end * FPS)) - done; settled = b.copy(); ns = 0
        for fr in range(frames):
            t = fr / FPS
            while ns < len(strips) and t >= starts[ns] + ANIM:               # this part has arrived: bake it into the still image
                settled.paste(strips[ns][0], (0, strips[ns][1]), strips[ns][0]); ns += 1
            im = settled.copy()
            for j in range(ns, len(strips)):
                if t < starts[j]: continue
                e = ease((t - starts[j]) / ANIM); s = strips[j][0]; a = s.getchannel("A").point(lambda v, e=e: int(v * e))
                im.paste(s, (0, strips[j][1] + int((1 - e) * RISE)), a)
            bar(im, n, i, (fr + 1) / frames)
            for c0, c1, cim in caps:                                             # running caption between the card and the footer
                if c0 <= t < c1: im.paste(cim, ((W - cim.width) // 2, CAPY), cim); break
            if prev is not None and t < XFADE: im = Image.blend(prev, im, t / XFADE)
            ff.stdin.write(im.tobytes())
        prev = im; done += frames
    ff.stdin.close()
    if ff.wait() != 0: raise RuntimeError("ffmpeg failed")
