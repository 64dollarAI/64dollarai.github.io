#!/usr/bin/env python3
"""Make a narrated vertical video (1080x1920) or a wide one (1920x1080) from a script file.

  python make_reel.py example.json            -> out/example.mp4 and out/example.txt (the caption)

Script format (JSON):
  {"caption": "text for the post",
   "voice": "am_michael", "speed": 1.2, "reveal": true, "captions": true, "format": "tall" | "wide",
   "segments": [{"say": "spoken text of this slide",
                 "tag": "SHORT LABEL",
                 "parts": [["line on screen", size, "fg|dim|acc|up|down", bold]]}]}
Every segment is one slide and lasts as long as its spoken text. The first slide is complete on the very first frame,
so platforms use it as the cover. With "reveal" the parts of the other slides appear one after another.
Needs: ffmpeg on the PATH, and the Python packages from requirements.txt. The voice (Kokoro) runs offline.
"""
import json, os, subprocess, sys, tempfile, wave
import kitbase, reel_fx
PAUSE = 0.35


def main(path):
    sc = json.load(open(path)); name = os.path.splitext(os.path.basename(path))[0]; tmp = tempfile.mkdtemp(prefix="reel_"); out = os.path.join(kitbase.ROOT, "out"); os.makedirs(out, exist_ok=True)
    wavs = [os.path.join(tmp, "a%d.wav" % i) for i in range(len(sc["segments"]))]
    subprocess.run([sys.executable, os.path.join(kitbase.ROOT, "say.py"), sc.get("voice", "am_michael"), str(sc.get("speed", 1.2))],
                   input=json.dumps([[s["say"], w] for s, w in zip(sc["segments"], wavs)]).encode(), check=True)
    durs = []
    for w in wavs:
        f = wave.open(w); durs.append(f.getnframes() / f.getframerate() + PAUSE); f.close()
    mp4 = os.path.join(out, name + ".mp4"); reel_fx.render(sc, wavs, durs, [], mp4, tmp)
    open(os.path.join(out, name + ".txt"), "w").write(sc.get("caption", ""))
    print(mp4, "%.1f s" % sum(durs), " ".join("%.1f" % d for d in durs))


if __name__ == "__main__":
    main(sys.argv[1])
