#!/bin/sh
# One-time setup: a Python environment and the two voice model files (about 340 MB, from the kokoro-onnx project on GitHub).
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
mkdir -p voice
for f in kokoro-v1.0.onnx voices-v1.0.bin; do
  [ -s "voice/$f" ] || curl -L --fail -o "voice/$f" "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/$f"
done
echo "Ready. Try:  .venv/bin/python make_reel.py example.json"
