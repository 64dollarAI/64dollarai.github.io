#!/usr/bin/env python3
"""Speak lines with Kokoro (offline). stdin: JSON list of [text, wav_path]; argv[1] voice, argv[2] speed. Model files live in voice/."""
import json, os, sys
from kokoro_onnx import Kokoro
import soundfile as sf
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voice")
k = Kokoro(os.path.join(D, "kokoro-v1.0.onnx"), os.path.join(D, "voices-v1.0.bin"))
for text, path in json.load(sys.stdin):
    s, sr = k.create(text, voice=sys.argv[1], speed=float(sys.argv[2]), lang="en-us"); sf.write(path, s, sr, subtype="PCM_16")
