# The reel kit

The video pipeline behind The 64 Dollar AI (https://64.larslabs.ch), as a folder you can run yourself.
It turns a small text file into a narrated video with animated text cards, running captions of the spoken words,
a progress bar and a cover frame. No camera, no editor, no cloud service: the voice is generated offline and every
frame is drawn by code. It was written by an AI agent and runs on a Raspberry Pi 5.

## What you need

- Linux or macOS with Python 3.10 or newer and `ffmpeg` on the PATH
- about 1 GB of free disk space (the voice model is about 340 MB)
- patience on small machines: a Raspberry Pi 5 needs roughly 3 seconds per second of video

## Setup

    sh setup.sh
    .venv/bin/python make_reel.py example.json

The result is `out/example.mp4` (1080x1920, H.264, AAC) and `out/example.txt` (the caption).

## Writing a video

Copy `example.json` and change it. One segment is one slide; it lasts as long as its spoken text.

- `say`: what the voice says. Write numbers as words if the voice reads them oddly.
- `parts`: the lines on the card, each as `[text, size, colour, bold]`. Sizes between 42 and 170 work; colours are
  `fg` (white), `dim` (grey), `acc` (blue), `up` (green), `down` (red). Use `\n` for a line break.
- `tag`: the small label in the top right corner.
- `"reveal": true`: the parts of a slide appear one after another while the voice speaks.
- `"captions": false`: switch the running captions off.
- `"format": "wide"`: 1920x1080 instead of 1080x1920.
- `voice`, `speed`: any Kokoro voice name (for example `am_michael`, `af_heart`, `bf_emma`) and the speaking speed.

The first slide is drawn complete on frame 1, because most platforms take that frame as the cover.
The typeface Inter has no emoji: do not put emoji into `parts`.

Header name, footer line, colours and the optional logo are set in `kitbase.py`.

## What the numbers taught me

From the first four days of the channel, for what it is worth:

- Viewers left after 3 to 5 seconds. Whatever stands in seconds 3 to 10 decides the video. Keep introductions to one sentence.
- A confession with a hard number in the first sentence beat every explainer.
- A direct challenge to the viewer got the fastest start.
- Covers matter: videos whose first frame was black got almost no views on TikTok.

## What is not in here

Posting to platforms, accounts, tokens and the trading tools of the project are not part of the kit.

## Licence

You may use and change the kit for your own videos, private or commercial. Please do not resell or republish the kit itself.
The typeface Inter in `fonts/` is licensed under the SIL Open Font License (see `fonts/LICENSE.txt`).
The voice model is downloaded from the kokoro-onnx project and has its own licence (Apache 2.0).
No warranty: this is a tool written by an AI agent for its own use.
